package com.example.VetSurgery;


import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.Locale;

/**
 * JavaFX App
 */
public class SurgeryInterface extends Application {

    private AnimalsWaiting animalsWaitingForVet;

    private final int WIDTH = 1500;
    private final int HEIGHT = 700;
    // visual components
    private final Label headingLabel = new Label("Book Animal into the Vet");
    private final Label vehicleLabel = new Label("Animal Details");
    private final Label regLabel = new Label("ID of the Animal");
    private final TextField regField = new TextField();
    private final Label makeLabel = new Label("Species");
    private final TextField makeField = new TextField();
    private final Label modelLabel = new Label("Name of the Animal");
    private final TextField modelField = new TextField();
    private final Separator sectSeparator = new Separator();
    private final Separator sectSeparator2 = new Separator();
    private final Separator sectSeparator3 = new Separator();
    private final Separator sectSeparator4 = new Separator();
    private final Label ownerLabel = new Label("Owner Details");
    private final Label nameLabel = new Label("Given Name");
    private final TextField nameField = new TextField();
    private final Label surnameLabel = new Label("Last Name ");
    private final TextField surnameField = new TextField();
    private final TextArea displayAnimals = new TextArea();
    private final Button addButton = new Button("Book in Animal");
    private final Button newBookingButton = new Button("New Booking");


    @Override
    public void start(Stage stage) {
        // Set default locale to English
        Locale.setDefault(Locale.ENGLISH);

        // Initialize the AnimalsWaiting class with a maximum number of 20
        animalsWaitingForVet = new AnimalsWaiting(20);

        // Create horizontal boxes for the animal and owner details
        HBox animalDetails = new HBox(10);
        HBox ownerDetails = new HBox(10);

        // Add components to HBoxes
        animalDetails.getChildren().addAll(regLabel, regField, makeLabel, makeField, modelLabel, modelField);
        ownerDetails.getChildren().addAll(nameLabel, nameField, surnameLabel, surnameField);

        // Create VBox and add all components to it
        VBox root = new VBox(10);
        root.getChildren().addAll(headingLabel, sectSeparator, vehicleLabel, animalDetails, sectSeparator2,
                ownerLabel, ownerDetails, sectSeparator3, displayAnimals, sectSeparator4, addButton, newBookingButton);

        // Set alignment of HBoxes and VBox
        animalDetails.setAlignment(Pos.BASELINE_CENTER);
        ownerDetails.setAlignment(Pos.TOP_CENTER);
        addButton.setAlignment(Pos.CENTER);
        newBookingButton.setAlignment(Pos.CENTER);
        root.setAlignment(Pos.CENTER);
        root.setBackground(Background.EMPTY);

        // Set maximum size of the TextArea
        displayAnimals.setMaxSize(800, 900);

        // Set the stage size
        stage.setWidth(WIDTH);
        stage.setHeight(HEIGHT);

        // Set scene and its background color
        Scene scene = new Scene(root);
        scene.setFill(Color.web("#FFE992"));
        addButton.setStyle("-fx-background-color: black; -fx-text-fill: #FFF6D2");
        newBookingButton.setStyle("-fx-background-color: black; -fx-text-fill: #FFF6D2");
        stage.setScene(scene);
        stage.setTitle("Ali's Vet Surgery");

        // Set button event handler
        addButton.setOnAction(e -> addHandler());
        newBookingButton.setOnAction(e ->
        {
            clearInput(regField, makeField, modelField, nameField, surnameField);
        });
        // Show the stage
        stage.show();
    }

    private void addHandler() {
        String animalReg = regField.getText();
        String species = makeField.getText();
        String animalName = modelField.getText();
        String givenName = nameField.getText();
        String surname = surnameField.getText();

        // Check for errors
        if (animalReg.isEmpty() || species.isEmpty() || animalName.isEmpty()) {
            displayAnimals.setText("You must enter the registration, species, and name of the animal.");
        } else if (givenName.isEmpty() || surname.isEmpty()) {
            displayAnimals.setText("You must enter both your given name and surname.");
        } else {
            // Add the animal
            Animal animalToAdd = new Animal(animalReg, species, animalName, givenName, surname);
            animalsWaitingForVet.addAnimal(animalToAdd);

            // Clear the fields
            regField.setText("");
            makeField.setText("");
            modelField.setText("");
            nameField.setText("");
            surnameField.setText("");

            // Update the display
            displayAnimals.setText(animalReg + " successfully added.\n\nThe animals awaiting to see the vet:\n");
            displayAnimals.appendText(animalsWaitingForVet.displayTheAnimals());
        }
    }


    private void clearInput(TextField regField, TextField makeField, TextField modelField, TextField nameField, TextField surnameField){

        displayAnimals.clear();
    }






    public static void main(String[] args) {
        launch();
    }
}
